import java.util.Scanner;
import java.io.*;
import java.net.*;
public class two
{
    public static void main(String args[])
    {
      try
      {
          FileInputStream fin=new FileInputStream("a.txt");
          BufferedReader br=new BufferedReader(new InputStreamReader(fin));
          String s;
          InetAddress ip;
          while((s=br.readLine())!=null)
          {
            if(s.equals("end"))
                break;
            if(s.charAt(0)>='0'&&s.charAt(0)<='9')
            {
              try{
                System.out.print("Host Name for Ip Address ::  " + s + " is ");
                ip=InetAddress.getByName(s);
                System.out.println(ip.getHostName());
              }
              catch(UnknownHostException e)
              {
                e.printStackTrace();
              }
            }
            if((s.charAt(0)>='a'&&s.charAt(0)<='z')||(s.charAt(0)>='A'&&s.charAt(0)<='Z'))
            {
              try{
                  System.out.print("Ip Address for Host :: " + s + " is ");
                  ip=InetAddress.getByName(s);
                  System.out.println(ip.getHostAddress());
              }
              catch(UnknownHostException e)
              {
                e.printStackTrace();
              }

            }
          }
          fin.close();
          br.close();
      }
      catch(Exception e)
      {}
    }
}
