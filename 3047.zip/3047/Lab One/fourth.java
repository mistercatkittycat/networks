import java.util.*;
import java.net.*;
import java.io.*;
public class fourth
{
        public static void main(String args[]) throws Exception
        {
                Socket s=new Socket("localhost",7);
		DataInputStream din = new DataInputStream(s.getInputStream());
		long time = din.readLong();
		System.out.println("Long: "+time);
		System.out.println("Date: "+new Date(time));
                din.close();
                s.close();
        }
};

