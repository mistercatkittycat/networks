import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

public class client
{
	private Frame mainFrame;
	private Label markLabel,statusLabel;
	private Panel fieldPanel,buttonPanel;
	private TextField host,port;
	private Button button[][],connect;
	private Socket s;
	private DataInputStream in;
	private DataOutputStream out;
	
	public client()
	{
		mainFrame=new Frame("Tic Tac Toe Client");
		mainFrame.setSize(500,800);
		mainFrame.setLayout(new GridLayout(4, 1));
		mainFrame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent){
				System.exit(0);
			}
      	});

		markLabel=new Label();
      	markLabel.setAlignment(Label.CENTER);

      	fieldPanel=new Panel();
      	fieldPanel.setLayout(new GridLayout(1,3));
      	host=new TextField();
      	port=new TextField();
      	connect=new Button("Connect");
      	connect.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				connectServer();
			}
		});
      	fieldPanel.add(host);
      	fieldPanel.add(port);
      	fieldPanel.add(connect);

      	buttonPanel=new Panel();
      	buttonPanel.setLayout(new GridLayout(10,10));
      	button=new Button[10][10];
      	for(int i=0;i<10;i++)
      	{
      		for(int j=0;j<10;j++)
      		{
	      		button[i][j]=new Button();
	      		button[i][j].addActionListener(new ActionListener(){
	      			public void actionPerformed(ActionEvent e)
	      			{
	      				Button source=(Button)e.getSource();
	      				source.setLabel(markLabel.getText());

	      				for(int i=0;i<10;i++)
	      				{
	      					boolean flag=true;
	      					for(int j=0;j<10;j++)
	      					{
		      					if(button[i][j]==source)
		      					{
		      						for(int pi=0;pi<10;pi++)
				      	 				for(int pj=0;pj<10;pj++)
												button[pi][pj].setEnabled(false);
									try{
										out.writeUTF(Integer.toString(i)+":"+Integer.toString(j));
										if(check(i,j))
										{
											out.writeUTF("true");
											statusLabel.setText("You have won...");
											finishGame(true);
										}
										else
										{
											out.writeUTF("false");
											waitForOpp();
										}
									}
									catch(Exception ex)
									{
										System.out.println(ex);
									}
		      						return;
		      					}
		      				}
	      				}
	      			}
	      		});
	      		button[i][j].setEnabled(false);
	      		buttonPanel.add(button[i][j]);
	      	}
      	}

      	statusLabel=new Label();
      	statusLabel.setText("waiting for connection to server...");
      	statusLabel.setAlignment(Label.CENTER);

      	mainFrame.add(markLabel);
     	mainFrame.add(fieldPanel);
      	mainFrame.add(buttonPanel);
      	mainFrame.add(statusLabel);

      	mainFrame.setVisible(true);
	}
	private void connectServer()
	{
		markLabel.setText("");
		statusLabel.setText("waiting for connection to server...");
		for(int i=0;i<10;i++)
		{
			for(int j=0;j<10;j++)
			{
				button[i][j].setLabel("");
			}
		}
		try
		{
			s=new Socket(host.getText(),Integer.parseInt(port.getText()));
			statusLabel.setText("Connected to server...");
			in=new DataInputStream(s.getInputStream());
			out=new DataOutputStream(s.getOutputStream());
			markLabel.setText(in.readUTF());
			statusLabel.setText("Waiting for opponent to connect...");
			in.readUTF();
			statusLabel.setText("Opponent has connected...");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		startGame();
	}
	private void finishGame(boolean won)
	{
		
      	if(won)
      		statusLabel.setText("You have Won...To play again, reconnect to server");
      	else
      		statusLabel.setText("You have Lost...To play again, reconnect to server");
	}
	private void waitForOpp()
	{
		try
		{
			statusLabel.setText("Waiting for Opponent move...");
			while(in.available()<=0);
			String pos=in.readUTF();
			String[] parts = pos.split(":");
			int posi=Integer.parseInt(parts[0]);
			int posj=Integer.parseInt(parts[1]);
			if(markLabel.getText().equals("X"))
			{
				button[posi][posj].setLabel("O");
			}
			else
			{
				button[posi][posj].setLabel("X");
			}
			button[posi][posj].requestFocus();
			while(in.available()<=0);
			String lost=in.readUTF();
			if(lost.equals("true"))
			{
				statusLabel.setText("Opponent has won...");
				finishGame(false);
			}
			else
			{
				for(int i=0;i<10;i++)
				 	for(int j=0;j<10;j++)
				 	{
				 		if(button[i][j].getLabel().equals(""))
				 			button[i][j].setEnabled(true);
				 	}
				statusLabel.setText("Make your move...");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public void startGame()
	{
		if(markLabel.getText().equals("X"))
		{
			for(int i=0;i<10;i++)
			 	for(int j=0;j<10;j++)
			 	{
			 		if(button[i][j].getLabel().equals(""))
			 			button[i][j].setEnabled(true);
			 	}
			statusLabel.setText("Make your move...");
		}
		else
		{
			waitForOpp();
		}
	}
	private boolean check(int posi,int posj)
	{
		String type = markLabel.getText();
		int left = (posj-5)>=0?(posj-5):0;
		int right = (posj+5)<10?(posj+5):9;
		int top = (posi-5)>=0?(posi-5):0;
		int bottom = (posi+5)<10?(posi+5):9;
		int count=0;
		for(int i=top, j=left;i<=bottom && j<=right;i++,j++){
			if(count==5){
				return true;
			}
			if(button[i][j].getLabel().equals(type)){
				count++;
			}else{
				count=0;
			}
		}
		if(count==5){
				return true;
		}
		count=0;
		for(int i=bottom, j=left; i<=top && j<=right;i--,j++){
			if(count==5){
				return true;
			}
			if(button[i][j].getLabel().equals(type)){
				count++;
			}else{
				count=0;
			}
		}
		if(count==5){
				return true;
		}
		count=0;
		for(int i=left;i<=right;i++){
			if(count==5){
				return true;
			}
			if(button[posi][i].getLabel().equals(type)){
				count++;
			}else{
				count=0;
			}
		}
		if(count==5){
				return true;
		}
		count=0;
		for(int i=top;i<=bottom;i++){
			if(count==5){
				return true;
			}
			if(button[i][posj].getLabel().equals(type)){
				count++;
			}else{
				count=0;
			}
		}
		if(count==5){
				return true;
		}
		return false;
	}
	public static void main(String args[])
	{
		client x= new client();
	}
};
