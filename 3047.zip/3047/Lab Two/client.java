import java.io.*;
import java.util.*;
import java.net.*;

public class client{
    
    public static void main(String[] args){
        try{
	Scanner in = new Scanner(System.in);
System.out.println("Enter file to download");
String str = in.nextLine();
            Socket s = new Socket("localhost",1234);
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
            dos.writeUTF(str);
            DataInputStream dis = new DataInputStream(s.getInputStream());
            System.out.println(dis.readUTF());
        }catch(Exception e){
            System.out.println(e);
        }
    }
}
