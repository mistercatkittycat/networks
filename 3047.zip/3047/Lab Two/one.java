import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.*;
import java.util.*;
import java.net.*;
public class one {
	public static void main(String[] args) throws IOException {
		ServerSocket socket = new ServerSocket(1234);
		Socket s = socket.accept();
		DataInputStream disi = new DataInputStream(s.getInputStream());
		DataOutputStream dos = new DataOutputStream(s.getOutputStream());
		String furl = disi.readUTF();
		System.out.println(furl);

        String save = "/home/student/Desktop";
	URL url = new URL(furl);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        int res= con.getResponseCode();
		if (res == HttpURLConnection.HTTP_OK) {
            String filename = "";
            String dis = con.getHeaderField("Content-Disposition");
            String type = con.getContentType();
            int contentLength = con.getContentLength();

            if (dis!= null) {
                int index = dis.indexOf("filename=");
                if (index > 0) {
                    filename = dis.substring(index + 10,
                            dis.length() - 1);
                }
            } else {
                filename = furl.substring(furl.lastIndexOf("/") + 1,
                        furl.length());
            }
			InputStream in = con.getInputStream();
            String path = save + File.separator + filename;
			FileOutputStream out = new FileOutputStream(path);

            int b = -1;
            byte[] buff = new byte[1024];
            while ((b = in.read(buff)) != -1) {
                out.write(buff, 0, b);
            }

            out.close();
            in.close();

            dos.writeUTF("File downloaded");
        } else {
            dos.writeUTF("No file to download. Server replied HTTP code: " + res);
        }
        con.disconnect();

	}
}
