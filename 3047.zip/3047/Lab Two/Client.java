    import java.net.*;  
    import java.io.*;  
    import java.util.*;
    class Client{
    char[][] ttt= new char [3][3];
    public static void checkdraw(){
        int flag=0;
        int win=1;
        for(int i=0;i<3;i++)
            for(int j=0;j<3;j++)
                if(ttt[i][j]=='.')
                    flag=1;
        for(int i=0;i<3;i++){
         if(ttt[i][i]!=='X')
            win=0;
        }
        for(int i=0;i<3;i++){
         if(ttt[i][1]!=='X')
            win=0;
        }
        if(flag==0){
            System.out.println("DRAW");
            System.exit(0);
        }
    }  
    public static void main(String args[])throws Exception{  
    Socket s=new Socket("localhost",3333);  
    DataInputStream din=new DataInputStream(s.getInputStream());  
    DataOutputStream dout=new DataOutputStream(s.getOutputStream());  
    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));  
    Scanner in = new Scanner(System.in);
    
    for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
            ttt[i][j]='.';
    int str1=0,str2,ser,cli;  
    while(str1!=10){  
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                System.out.print(ttt[i][j]);
            }
        System.out.println();
    }
        System.out.println();

    str1=in.nextInt();
    str2=in.nextInt();
    ttt[str1-1][str2-1]='X';
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            System.out.print(ttt[i][j]);
        }
    System.out.println();
    }
        System.out.println();
  
    dout.writeInt(str1);
    dout.flush();  
    dout.writeInt(str2);
    dout.flush();
    ser=din.readInt();
    cli=din.readInt();  
    ttt[ser-1][cli-1]='O';
    for(int i=0;i<3;i++){
    for(int j=0;j<3;j++){
    System.out.print(ttt[i][j]);
}
System.out.println();
}
    System.out.println();

}  
      
    dout.close();  
    s.close();  
    }}  